function(input, output, session) {
  
  source("./server/optimize_price.R", local = TRUE)
  
}


